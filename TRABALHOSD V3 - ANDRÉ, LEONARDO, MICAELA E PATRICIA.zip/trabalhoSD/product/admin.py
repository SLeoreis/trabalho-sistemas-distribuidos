from django.contrib import admin
from .models import *

admin.site.register(Cadastro)



# Register your models here.
